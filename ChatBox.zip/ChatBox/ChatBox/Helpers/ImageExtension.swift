//
//  NewMessageExtension.swift
//  ChatBox
//
//  Created by new user on 12/5/19.
//  Copyright © 2019 new user. All rights reserved.
//

import Foundation
import UIKit

let imageCache = NSCache<NSString, AnyObject>()

extension UIImageView {
    
    func loadImageUsingCache(_ urlString: String) {
        
        self.image = nil
        
        //check cache for image first
        if let cachedImageView = imageCache.object(forKey: urlString as NSString) as? UIImage {
            self.image = cachedImageView
            return
        }
        
        //otherwise fire off a new download
        let url = URL(string: urlString)
        URLSession.shared.dataTask(with: url!, completionHandler: { (data, response, error) in
            
            //download hit an error so lets return out
            if let error = error {
                print(error)
                return
            }
            
            DispatchQueue.main.async(execute: {
                
                if let downloadedImageView = UIImage(data: data!) {
                    imageCache.setObject(downloadedImageView, forKey: urlString as NSString)
                    
                    self.image = downloadedImageView
                }
            })
            
        }).resume()
    }
    
}
