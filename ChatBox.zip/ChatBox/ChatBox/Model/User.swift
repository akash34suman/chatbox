//
//  User.swift
//  ChatBox
//
//  Created by new user on 12/5/19.
//  Copyright © 2019 new user. All rights reserved.
//

import Foundation
import UIKit

class User: NSObject {
    var id :String?
    var name: String?
    var email: String?
    var profileImageUrl: String?
    
    init(dictionary: [AnyHashable: Any]) {
        self.name = dictionary["name"] as? String
        self.email = dictionary["email"] as? String
        self.profileImageUrl = dictionary["profileImageUrl"] as? String
    }
}
