//
//  ViewController.swift
//  ChatBox
//
//  Created by new user on 12/5/19.
//  Copyright © 2019 new user. All rights reserved.
//

import UIKit
import Firebase
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
    switch (lhs, rhs) {
    case let (l?, r?):
        return l < r
    case (nil, _?):
        return true
    default:
        return false
    }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
    switch (lhs, rhs) {
    case let (l?, r?):
        return l > r
    default:
        return rhs < lhs
    }
}

class MessageViewController: UITableViewController {
    let cellID = "cell"
  

    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Logout", style: .plain, target: self, action: #selector(logOutUser))
        
        let image = UIImage(named: "newmsg")
        navigationItem.rightBarButtonItem = UIBarButtonItem(image: image, style: .plain, target: self, action: #selector(getNewMessage))
        
       checkIfUserIsLoggedIn()
        tableView.register(UserViewCell.self, forCellReuseIdentifier: cellID)
        tableView.allowsMultipleSelectionDuringEditing = true
    }
    
    var messages = [Message]()

    var messagesDictionary = [String: Message]()
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        guard let uid = Auth.auth().currentUser?.uid else {
            return
        }
        
        let message = self.messages[indexPath.row]
        
        if let chatMsgPartnerId = message.chatMsgPartnerId() {
            Database.database().reference().child("user_messages").child(uid).child(chatMsgPartnerId).removeValue(completionBlock: { (error, ref) in
                
                if error != nil {
                    print("Unable to delete message:", error!)
                    return
                }
                
                self.messagesDictionary.removeValue(forKey: chatMsgPartnerId)
                self.reloadingOfTableWithSort()
                
            })
        }
    }
    
    
    func getUserMessages() {
        guard let uid = Auth.auth().currentUser?.uid else {
            return
        }
        
        let ref = Database.database().reference().child("user_messages").child(uid)
        ref.observe(.childAdded, with: { (snapshot) in
            
            let userId = snapshot.key
            
            print(uid, userId)
            Database.database().reference().child("user_messages").child(uid).child(userId).observe(.childAdded, with: { (snapshot) in
                
                let messageId = snapshot.key
                self.getMsgWithMessageId(messageId)
                
            }, withCancel: nil)
            
        }, withCancel: nil)
        
        ref.observe(.childRemoved, with:  { (snapshot) in
            
            print(snapshot.key)
            print(self.messagesDictionary)
            self.messagesDictionary.removeValue(forKey: snapshot.key)
            self.reloadingOfTableWithSort()
            
        }, withCancel: nil)
    }
    
    fileprivate func getMsgWithMessageId(_ messageId: String) {
        let msgsReference  = Database.database().reference().child("messages").child(messageId)
        
        msgsReference .observeSingleEvent(of: .value, with: { (snapshot) in
            
            if let dictionary = snapshot.value as? [String: AnyObject] {
                let message = Message(dictionary: dictionary)
                
                if let chatMsgPartnerId = message.chatMsgPartnerId() {
                    self.messagesDictionary[chatMsgPartnerId] = message
                }
                
                self.reloadingOfTableWithSort()
            }
            
        }, withCancel: nil)
    }
    
    fileprivate func reloadingOfTableWithSort() {
        self.timer?.invalidate()
        
        self.timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(self.sortReloadTable), userInfo: nil, repeats: false)
    }
    
    var timer: Timer?
    
    @objc func sortReloadTable() {
        self.messages = Array(self.messagesDictionary.values)
        self.messages.sort(by: { (message1, message2) -> Bool in
            
            return message1.timestamp?.int32Value > message2.timestamp?.int32Value
        })
        
        // to avoid the crash
        DispatchQueue.main.async(execute: {
            self.tableView.reloadData()
        })
    }
    
    
   
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellID, for: indexPath) as! UserViewCell
        
        let message = messages[indexPath.row]
        cell.message = message
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 72
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let message = messages[indexPath.row]
        print (message.text, message.fromId, message.toId)
        guard let chatMsgPartnerId = message.chatMsgPartnerId() else {
            return
        }
        
        let ref = Database.database().reference().child("users").child(chatMsgPartnerId)
        ref.observeSingleEvent(of: .value, with: { (snapshot) in
            guard let dictionary = snapshot.value as? [String: AnyObject] else {
                return
            }
            
            let user = User(dictionary: dictionary)
            user.id = chatMsgPartnerId
            self.showChatViewController(user: user)
            
        }, withCancel: nil)
    }
    @objc func getNewMessage() {
        let newMessageController = NewMessageTableViewController()
        newMessageController.messageViewController = self
        let navController = UINavigationController(rootViewController: newMessageController)
        present(navController, animated: true, completion: nil)
    }
    
    func checkIfUserIsLoggedIn() {
        if Auth.auth().currentUser?.uid == nil {
            perform(#selector(logOutUser), with: nil, afterDelay: 0)
        } else {
            getNavBarTitle()
        }
    }
    func getNavBarTitle() {
        guard let uid = Auth.auth().currentUser?.uid else {
            //for some reason uid = nil
            return
        }
        
        Database.database().reference().child("users").child(uid).observeSingleEvent(of: .value, with: { (snapshot) in
            
            if let dictionary = snapshot.value as? [String: AnyObject] {
                let user = User(dictionary: dictionary)
                self.setNavBarWithUser(user)
            }
            
        }, withCancel: nil)
    }
    
    func setNavBarWithUser(_ user: User) {
        messages.removeAll()
        messagesDictionary.removeAll()
        tableView.reloadData()
        getUserMessages()
        
        let titleView = UIView()
        titleView.frame = CGRect(x: 0, y: 0, width: 100, height: 40)
        //        titleView.backgroundColor = UIColor.redColor()
        
        let blockView = UIView()
        blockView.translatesAutoresizingMaskIntoConstraints = false
        titleView.addSubview(blockView)
        
        let profileImgView = UIImageView()
        profileImgView.translatesAutoresizingMaskIntoConstraints = false
        profileImgView.contentMode = .scaleAspectFill
        profileImgView.layer.cornerRadius = 20
        profileImgView.clipsToBounds = true
        if let profileImageUrl = user.profileImageUrl {
            profileImgView.loadImageUsingCache(profileImageUrl)
        }
        
        blockView.addSubview(profileImgView)
        
        //ios 9 constraint anchors
        //need x,y,width,height anchors
        profileImgView.leftAnchor.constraint(equalTo: blockView.leftAnchor).isActive = true
        profileImgView.centerYAnchor.constraint(equalTo: blockView.centerYAnchor).isActive = true
        profileImgView.widthAnchor.constraint(equalToConstant: 40).isActive = true
        profileImgView.heightAnchor.constraint(equalToConstant: 40).isActive = true
        
        let nameLabel = UILabel()
        
        blockView.addSubview(nameLabel)
        nameLabel.text = user.name
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        //need x,y,width,height anchors
        nameLabel.leftAnchor.constraint(equalTo: profileImgView.rightAnchor, constant: 8).isActive = true
        nameLabel.centerYAnchor.constraint(equalTo: profileImgView.centerYAnchor).isActive = true
        nameLabel.rightAnchor.constraint(equalTo: blockView.rightAnchor).isActive = true
        nameLabel.heightAnchor.constraint(equalTo: profileImgView.heightAnchor).isActive = true
        
        blockView.centerXAnchor.constraint(equalTo: titleView.centerXAnchor).isActive = true
        blockView.centerYAnchor.constraint(equalTo: titleView.centerYAnchor).isActive = true
        
        self.navigationItem.titleView = titleView

    }
func showChatViewController(user: User) {
        let chatViewController = ChatViewController(collectionViewLayout: UICollectionViewFlowLayout())
        chatViewController.user = user
        navigationController?.pushViewController(chatViewController, animated: true)
    }
    
    @objc func logOutUser() {
        
        do {
            try Auth.auth().signOut()
        } catch let logoutError {
            print(logoutError)
        }
        
        let loginViewController = LoginViewController()
        loginViewController.messageViewController = self
        present(loginViewController, animated: true, completion: nil)
    }



}

